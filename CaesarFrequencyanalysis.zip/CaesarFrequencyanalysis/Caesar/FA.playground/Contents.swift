import Foundation

 var textArray = [String]()

func readFromFile() {
    if let path = Bundle.main.path(forResource: "text", ofType: "txt") {
        if let text = try? String(contentsOfFile: path) {
            textArray = text.components(separatedBy: "\n\n")
            
            print(text)
        }
    }
}


func counter(word: String) -> Bool {
    let textChecker = UITextChecker()
    
    let checkRange = NSMakeRange(0, word.characters.count)
    
    let stringRange = textChecker.rangeOfMisspelledWordInString(word, range: checkRange, startingAt: 0, wrap: false, language: "ru")
    
    return stringRange.location == NSNotFound
    
  }


func letters() {

words = dict()
for w in n:
if w in words {
words[w] += 1}
else {
words[w] = 0
}
words[w] = 0
 
MyList = list(words)
print(MyList)
i = 0
for w in words:
MyList[i-1] = (words[w], w)
 
MegaList = sorted(MyList, key=lambda x: x[0], reverse=True)

}
