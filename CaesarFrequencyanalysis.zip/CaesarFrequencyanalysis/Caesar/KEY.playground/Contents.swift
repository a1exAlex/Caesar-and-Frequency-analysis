let englishAlphabetСapitalLetter: [Character] = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
let  englishAlphabetLineLetter: [Character] = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]

let  russianAplhabetCapitalLetter: [Character] = ["А","Б","В","Г","Д","Е","Ё","Ж","З","И","Й","К","Л","М","Н","О","П", "Р","С","Т","У","Ф","Х","Ц","Ч","Ш","Щ","Ъ","Ы","Ь","Э","Ю","Я"]
let  russianAplhabetLineLetter: [Character] = ["а","б","в","г","д","е","ё","ж","з","и","й","к","л","м","н","о","п", "р","с","т","у","ф","х","ц","ч","ш","щ","ъ","ы","ь","э","ю","я"]



var outputArrayKey: [Character] = []

//: ### Приведение к множествам

var engAlphaCapLetterSet = Set(englishAlphabetСapitalLetter)
var engAlphaLineLetterSet = Set(englishAlphabetLineLetter)
var rusAlphaCapLetterSet = Set(russianAplhabetCapitalLetter)
var rusAlphaLineLetterSet = Set(russianAplhabetLineLetter)

var keywordSet: Set<Character> = []

//: ### Поиск сета по элементу

func setSearch(element: Character) -> Set<Character>? {
    let isContains = true
    
    switch isContains {
        
    case engAlphaCapLetterSet.contains(element):
        engAlphaCapLetterSet.remove(element)
        return engAlphaCapLetterSet
    
    case engAlphaLineLetterSet.contains(element):
        engAlphaLineLetterSet.remove(element)
        return engAlphaLineLetterSet
       
    case rusAlphaCapLetterSet.contains(element):
        rusAlphaCapLetterSet.remove(element)
        return rusAlphaCapLetterSet
        
    case rusAlphaLineLetterSet.contains(element):
        rusAlphaLineLetterSet.remove(element)
        return rusAlphaLineLetterSet
        
    default:
        return []
    }
}

//: ### Удаление повторяющихся элементов
func removalOfRepetitions(key: String) -> [Character]? {
    var array: [Character] = []
    
    for k in key {
    
        if !array.contains(k) {
            array.append(k)
        }
        outputArrayKey.append(k)
    }
    
    return array
}

//: ### Конвертация в массив и сортировка
func fromSetToArray(set: Set<Character>) -> [Character] {
    var arrayForConvert = Array(set)
    arrayForConvert.sort(by: <)
    return arrayForConvert
}
//: ### Поиск индекса
func indexSearch(symbol: Character) -> Int? {
   let isContains = true
    
    func index(alphabet: [Character], elem: Character) -> Int {
        let index = alphabet.index(of: symbol)
        return index!
    }
    
    switch isContains {
    case englishAlphabetСapitalLetter.contains(symbol):
        return index(alphabet: englishAlphabetСapitalLetter, elem: symbol)
     
    case englishAlphabetLineLetter.contains(symbol):
        return index(alphabet: englishAlphabetLineLetter, elem: symbol)
        
    case russianAplhabetCapitalLetter.contains(symbol):
        return index(alphabet: russianAplhabetCapitalLetter, elem: symbol)
        
    case russianAplhabetLineLetter.contains(symbol):
       return index(alphabet: russianAplhabetLineLetter, elem: symbol)
        
    default:
        return nil
    }
    
}
//: ### Основная функция шифра Цезаря с ключевым словом
func cipherWithKeyword(string: String, keyword: String) -> [Character] {

    var outputString: [Character] = []
    if let key = removalOfRepetitions(key: keyword) {
   
        for (index, value) in key.enumerated() {
            while index + 1 > key.count {
                setSearch(element: value)
            }
            keywordSet = setSearch(element: value)!
        }
        
       outputArrayKey += fromSetToArray(set: keywordSet)
        
        }
    
    
    for str in string {
        if let index = indexSearch(symbol: str) {
        outputString.append(outputArrayKey[index])
        }
    }
    
        return outputString
    }


cipherWithKeyword(string: "ABC", keyword: "S")







